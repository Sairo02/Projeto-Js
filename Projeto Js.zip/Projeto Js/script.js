document.addEventListener('DOMContentLoaded', function() {
    const listaDeProdutos = document.getElementById('lista-de-produtos');
    const formularioAdicionarProduto = document.getElementById('formulario-adicionar-produto');
    const formularioRemoverProduto = document.getElementById('formulario-remover-produto');
    const termoDeBusca = document.getElementById('termo-de-busca');
    const filtroDeCategoria = document.getElementById('filtro-de-categoria');

    formularioAdicionarProduto.addEventListener('submit', function(event) {
        event.preventDefault();

        const nomeDoProduto = document.getElementById('nome-do-produto').value;
        const quantidadeDoProduto = document.getElementById('quantidade-do-produto').value;
        const categoriaDoProduto = document.getElementById('categoria-do-produto').value;
        const preçoDoProduto = document.getElementById('preço-do-produto').value;
        const imagemDoProduto = document.getElementById('imagem-do-produto').value;
        
        const novoProdutoHTML = `
            <div class="item-de-produto" data-nome="${nomeDoProduto}" data-categoria="${categoriaDoProduto}">
                <img src="${imagemDoProduto}" alt="${nomeDoProduto}">
                <div>
                    <h3>${nomeDoProduto}</h3>           
                    <p>Quantidade disponível: ${quantidadeDoProduto}</p>
                    <p>Categoria: ${categoriaDoProduto}</p>
                    <p>Preço: R$ ${preçoDoProduto}</p>
                </div>
            </div>
        `;

        listaDeProdutos.insertAdjacentHTML('beforeend', novoProdutoHTML);
       formularioAdicionarProduto.reset(); });
    
 
    formularioRemoverProduto.addEventListener('submit', function(event) {
        event.preventDefault();

        const nomeDoProdutoParaRemover = document.getElementById('nome-do-produto-para-remover').value;

        const produtos = listaDeProdutos.getElementsByClassName('item-de-produto');
        for (let i = 0; i < produtos.length; i++) {
            if (produtos[i].getAttribute('data-nome') === nomeDoProdutoParaRemover) {
                listaDeProdutos.removeChild(produtos[i]);
                break; } }
            
        formularioRemoverProduto.reset(); });
    

    function filtrarProdutos() {
        const termo = termoDeBusca.value.toLowerCase();
        const categoria = filtroDeCategoria.value.toLowerCase();
        const produtos = listaDeProdutos.getElementsByClassName('item-de-produto');

        for (let i = 0; i < produtos.length; i++) {
            const nomeProduto = produtos[i].getAttribute('data-nome').toLowerCase();
            const categoriaProduto = produtos[i].getAttribute('data-categoria').toLowerCase();
 
            if ((nomeProduto.includes(termo) || termo === '') && (categoriaProduto === categoria || categoria === '')) {
                produtos[i].style.display = 'flex';
            } else {
                produtos[i].style.display = 'none'; } } }
            
       
    termoDeBusca.addEventListener('input', filtrarProdutos);
    filtroDeCategoria.addEventListener('change', filtrarProdutos);
});
